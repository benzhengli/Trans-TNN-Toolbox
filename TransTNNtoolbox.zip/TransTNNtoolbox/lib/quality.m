function [MPSNR, MSSIM] = quality(imagery1, imagery2)
%==========================================================================
% Evaluates the quality assessment indices for two tensors.
%
% Syntax:
%   [psnr, ssim] = quality(imagery1, imagery2)
%
% Input:
%   imagery1 - the reference tensor
%   imagery2 - the target tensor

% NOTE: the tensor is a M*N*K array and DYNAMIC RANGE [0, 255]. 

% Output:
%   psnr - Peak Signal-to-Noise Ratio
%   ssim - Structure SIMilarity

% See also StructureSIM, FeatureSIM
%
% by Yi Peng
% update by Yu-Bang Zheng 11/19/2018
%==========================================================================
Nway = size(imagery1);
PSNR = 0;%zeros(Nway(3),1);
SSIM = PSNR;
for i = 1:Nway(3)
    PSNR = psnr(imagery2(:, :, i), imagery1(:, :, i),255) + PSNR;
    SSIM = ssim(imagery2(:, :, i)./255, imagery1(:, :, i)./255) + SSIM;
end
MPSNR = PSNR / Nway(3);
MSSIM = SSIM / Nway(3);
