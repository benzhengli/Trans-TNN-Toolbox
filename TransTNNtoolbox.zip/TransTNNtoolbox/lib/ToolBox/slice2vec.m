function vec = slice2vec(zijslice,dim,i)
%
if length(dim) == 3
    vec = Unfold(zijslice,dim,i);
else
    vec = zijslice(:)';
end